ua-parser.min.js:
  https://github.com/faisalman/ua-parser-js/releases/tag/0.7.21
